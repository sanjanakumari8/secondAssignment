package com.example.assignment2.modal;

public class Register {
    String email,password;
    public Register(String email, String password){
        this.email=email;
        this.password=password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

}
